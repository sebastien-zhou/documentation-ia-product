package com.brainwave.portal.theme.skin;

import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setStyle;
import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setHexBackground;
import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setHexForeground;
import static com.brainwave.portal.ui.utils.widgets.WidgetFactoryExtension.newButtonCssIcon;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

import com.brainwave.iaudit.database.datasource.IDataSourceProvider;
import com.brainwave.portal.ui.skin.PortalSkinBase;
import com.brainwave.portal.ui.utils.layout.FillLayoutFactory;
import com.brainwave.portal.ui.utils.layout.FormDataFactory;
import com.brainwave.portal.ui.utils.layout.FormLayoutFactory;
import com.brainwave.portal.ui.utils.widgets.BreadCrumbBar;
import com.brainwave.portal.ui.widgets.HNavTabs;
import com.google.inject.Inject;
import com.google.inject.name.Named;

public class PortalSkin extends PortalSkinBase {

	private final static int TOOLBAR_HEIGHT = 62;
	@Inject(optional = true)	@Named(IDataSourceProvider.COLOR_BG_TOOLBAR) 	protected String m_colorBGToolbar;
	@Inject(optional = true)	@Named(IDataSourceProvider.COLOR_FG_MENU_ACTIVE)	protected String m_colorFGMenuActive;
	@Inject(optional = true)	@Named(IDataSourceProvider.COLOR_FG_MENU_INACTIVE)	protected String m_colorFGMenuInactive;
	@Inject(optional = true)	@Named(IDataSourceProvider.COLOR_BG_TIMESLOTS)	protected String m_colorBGTimeslots;
	@Inject(optional = true)	@Named(IDataSourceProvider.COLOR_FG_TIMESLOTS)	protected String m_colorFGTimeslots; 

	@Override
	public void createContent(final Composite parent) {
		createHeader(parent);
		createToolbar(parent);
		createPageArea(parent);
	}

	protected void createHeader(final Composite parent) {
		super.createHeader(parent);
	}

	protected void createToolbar(final Composite parent) {

		// container 
		m_toolbar = new Composite(parent, SWT.NONE);
		setStyle(m_toolbar, TOOLBAR_STYLE);
		setHexBackground(m_toolbar, m_colorBGToolbar);
		FormDataFactory.swtDefaults().top(m_header, 0).left(0).right(100).height(TOOLBAR_HEIGHT).applyTo(m_toolbar);
		FormLayoutFactory.swtDefaults().applyTo(m_toolbar);

		// header compact toggle
		m_headerCompactButton = new Button(m_toolbar, SWT.TOGGLE | SWT.FLAT);
		setStyle(m_headerCompactButton, COMPACT_HEADER_STYLE);
		FormDataFactory.swtDefaults().top(0, 5).left(0, 5).width(12).height(12).applyTo(m_headerCompactButton);

		// main menu
		m_mainMenuButton = newButtonCssIcon(m_toolbar, MAIN_MENU_STYLE);
		FormDataFactory.swtDefaults().top(50, -16).left(0, 10).width(32).height(32).applyTo(m_mainMenuButton);

		final Button loadingIcon = newButtonCssIcon(m_toolbar, LOADING_STYLE);
		FormDataFactory.swtDefaults().top(50,-16).left(m_mainMenuButton, 10).width(32).height(32).applyTo(loadingIcon);
		m_loadingIcon = loadingIcon;						

		m_timeslotLabel = new Button(m_toolbar, SWT.CENTER);
		setStyle(m_timeslotLabel, TIMESLOT_STYLE);
		setHexBackground(m_timeslotLabel, m_colorBGTimeslots);
		setHexForeground(m_timeslotLabel, m_colorFGTimeslots);
		FormDataFactory.swtDefaults().top(0, 5).right(100, (-5)).height(32).applyTo(m_timeslotLabel);

		// nav bar 		
		final HNavTabs navBar = new HNavTabs(m_toolbar, SWT.NONE);
		navBar.setColors(m_colorBGTimeslots, m_colorFGMenuInactive, m_colorFGMenuActive);
		final FormDataFactory navbarLD = FormDataFactory.swtDefaults().left(m_loadingIcon, 10, SWT.RIGHT).bottom(100, 0);
		if (m_timeslotLabel != null) {
			navbarLD.right(m_timeslotLabel, -10);
		} else {
			navbarLD.right(100, -10);
		}
		navbarLD.applyTo(navBar);
		m_navBar = navBar;
	}

	private void createPageArea(final Composite parent) {
		m_breadCrumbBar = new BreadCrumbBar(parent, ">");
		FormDataFactory.swtDefaults().top(m_toolbar, 0).left(0, 15).right(100, (-15)).height(10).applyTo(m_breadCrumbBar);
		m_pageArea = new Composite(parent, SWT.NONE);
		setStyle(m_pageArea, PAGE_AREA_STYLE);
		FormDataFactory.swtDefaults().top(m_breadCrumbBar, 0).bottom(100).left(0, 15).right(100, (-15)).applyTo(m_pageArea);
		FillLayoutFactory.fillDefaults().margins(0).applyTo(m_pageArea);
	}

}
