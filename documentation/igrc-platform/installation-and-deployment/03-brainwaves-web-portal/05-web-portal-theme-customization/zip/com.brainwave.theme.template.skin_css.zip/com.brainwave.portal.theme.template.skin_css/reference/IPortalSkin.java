package com.brainwave.portal.ui.skin;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;

import com.brainwave.portal.ui.utils.widgets.BreadCrumbBar;
import com.brainwave.portal.ui.visualization.navbar.INavBar;

public interface IPortalSkin {
	
	/**  this method is called to create the portal content: header, toolbar and page content area
	 * 
	 * @param parent : the container for the page, 
	 */
	void createContent(Composite parent);

	/**  expands / collapse the top header.
	 * 
	 * @param compact 
	 */
	void compactHeader(boolean compact );
	
	/* UI elements getters */
	
	/**
	 * @return the widget for the header title, or null if not present
	 */
	Label getHeaderTitle();	
	
	/**
	 * @return the widget for the permalink button , or null if not present
	 */	
	Button getPermaLinkButton();

	/**
	 * @return the widget to hold the dynamic image of the user. Usually it's an icon button
	 * return null if not present
	 */
	Control getUserIcon();
	   
	/** the widget to display the name of the current user, and a drop down menu. It's usually a Button
	 * @return the widget if present, or null if not present
	 */
	Button getUserBtn();
	
	Button getErrorLogButton();

	/** the burger button in the toolbar 
	 * 
	 * @return the widget or null if not present
	 */
	Button getMainMenuButton();
	
	/** the navigation panel, which implements INavBar.  Two implementations are provided: HNavTabs and VNavTabs
	 * 
	 * @return the widget, or null if not present
	 */
	 INavBar getNavBar();
	
	/** the icon that will dynamically hold the loading animated image. It's usually a Button widget
	 *  
	 * @return the widget, or null if not present
	 */
	Control getLoadingIcon();

	/** a two-state button (of type SWT.TOGGLE) to hold that button that expands/collapse the top header
	 * 
	 * @return  the widget, or null if not present
	 */
	Button getHeaderCompactButton();

	/** The button that displays the name of the current timeslot, and allows selecting another timeslot
	 * 
	 * @return  the widget, or null if not present
	 */	
	Button getTimeslotLabel();
	
	/** a composite that will hold the selected content of the page, without the bread crumbs
	 * 
	 * @return  the widget, or null if not present
	 */
	Composite getPageArea();

	/** an instance of BreadCrumbar to display the optional breadcrumbs for a page, at the top of the page area.
	 * 
	 * @return  the widget, or null if not present
	 */
    BreadCrumbBar getBreadCrumbBar();  

}
