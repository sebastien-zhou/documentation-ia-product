package com.brainwave.portal.ui.skin;

import com.brainwave.iaudit.database.datasource.IDataSourceProvider;
import com.brainwave.portal.ui.utils.DisplayResourcesManager;

import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setStyle;
import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setHexBackground;
import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setHexForeground;
import static com.brainwave.portal.ui.utils.widgets.WidgetFactoryExtension.newButtonCssIcon;


import com.brainwave.portal.ui.utils.layout.FormDataFactory;
import com.brainwave.portal.ui.utils.layout.FormLayoutFactory;
import com.brainwave.portal.ui.utils.widgets.BreadCrumbBar;
import com.brainwave.portal.ui.visualization.navbar.INavBar;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;

public abstract class PortalSkinBase implements IPortalSkin {

	protected static  String IMAGE_PREFIX = "bundle:com.brainwave.portal.ui:resources/";
	protected static final String TIMESLOT_STYLE = "timeslot";
	protected static final String COMPACT_HEADER_STYLE = "compact-header";
	protected static final String TOOLBAR_STYLE = "toolbar";
	protected static final String HEADER_ERROR_STYLE = "header-error";
	protected static final String HEADER_USER_STYLE = "header-user";
	protected static final String DOTMENU_STYLE = "dotmenu";
	protected static final String PERMALINK_STYLE = "permalink";
	protected static final String HEADER_TITLE_STYLE = "header-title";
	protected static final String PAGE_AREA_STYLE = "page-area";
	protected static final String LOADING_STYLE = "nav-loading";
	protected static final String MAIN_MENU_STYLE = "nav-main-menu";
	protected static final String HOME_STYLE = "nav-home";  
	
	@Inject  @Named(IDataSourceProvider.HEADER_LOGO)  protected String m_headerLogoPath; 
	@Inject  @Named(IDataSourceProvider.HEADER_LOGO_WIDTH)  protected int m_headerLogoWidth; 
	@Inject  @Named(IDataSourceProvider.HEADER_LOGO_HEIGHT)  protected int m_headerLogoHeight;  
	@Inject  @Named(IDataSourceProvider.COLOR_FG_TITLE)  protected String m_colorFGTitle;  	
	@Inject  @Named(IDataSourceProvider.COLOR_BG_TOP)  protected String m_colorBGTop;  	
	@Inject  @Named(IDataSourceProvider.HEADER_HEIGHT)  protected int m_headerHeight;  	
	@Inject(optional=true) @Named(IDataSourceProvider.COLOR_FG_USERNAME) protected String m_colorFGUsername;
	@Inject(optional=true) @Named(IDataSourceProvider.COLOR_FG_ERROR) protected String m_colorFGError;
		
	protected Composite m_header;

	protected Composite m_toolbar;

	protected Composite m_pageArea;

	protected Label m_logo;

	protected Label m_headerTitle;

	protected Button m_errorLogButton;

	protected Button m_permaLinkButton;

	protected Button m_userBtn;

	protected Button m_mainMenuButton;
	protected Control m_loadingIcon;
	protected Button m_headerCompactButton;
	protected INavBar m_navBar;
	protected Button m_timeslotLabel;
	protected BreadCrumbBar m_breadCrumbBar;
	protected Control m_userIcon; 

	@Override
	public Button getErrorLogButton() {
		return m_errorLogButton;
	}

	@Override
	public Button getHeaderCompactButton() {
		return m_headerCompactButton;
	}

	@Override
	public Label getHeaderTitle() {
		return m_headerTitle;
	}

	@Override
	public Button getMainMenuButton() {
		return m_mainMenuButton;
	}
	
	@Override
	public Control getLoadingIcon() {
		return m_loadingIcon;
	}

	@Override
	public Composite getPageArea() {
		return m_pageArea;
	}

	@Override
	public Button getPermaLinkButton() {
		return m_permaLinkButton;
	}

	@Override
	public Button getTimeslotLabel() {
		return m_timeslotLabel;
	}
	
	@Override
	public Control getUserIcon() {
		return m_userIcon;
	}

	@Override
	public Button getUserBtn() {
		return m_userBtn;
	}
	

	@Override
	public INavBar getNavBar() {
		return m_navBar;
	}

	@Override
	public BreadCrumbBar getBreadCrumbBar() {
		return m_breadCrumbBar;
	}
	
	/** default implementation of the top header, that create, from left to right:
	 *  the logo, the header title, the permalink button, the user image and name button and "show errors" button
	 * 
	 * @param parent
	 */
	protected void createHeader(final Composite parent) {
		// container
		final Composite header = new Composite(parent, SWT.NONE); 
	    setHexBackground(header, m_colorBGTop);	    
		FormDataFactory.swtDefaults().left(0).right(100).height(m_headerHeight).applyTo(header);
		FormLayoutFactory.fillDefaults().margins(0, 0, 20, 0).applyTo(header);
		m_header = header;
		
		// logo
		m_logo = new Label(m_header, SWT.NONE);
		m_logo.setImage(DisplayResourcesManager.getImage(m_headerLogoPath, m_headerLogoWidth, m_headerLogoHeight));
		FormDataFactory.swtDefaults().top(50, -m_headerLogoHeight/2).left(0).width(m_headerLogoWidth).height(m_headerLogoHeight).applyTo(m_logo);

		// title
		Label _label = new Label(m_header, SWT.NONE);
		m_headerTitle = _label;
		setStyle(m_headerTitle,HEADER_TITLE_STYLE);
		setHexForeground(m_headerTitle, m_colorFGTitle);
		FormDataFactory.swtDefaults().top(m_logo,0,SWT.CENTER).left(m_logo,  30).applyTo(m_headerTitle);
		// permalink button
		m_permaLinkButton = newButtonCssIcon(m_header, PERMALINK_STYLE);
		FormDataFactory.swtDefaults().top(50, -10).left(m_headerTitle, 15, SWT.RIGHT).width(16).height(16).applyTo(m_permaLinkButton);

		m_userBtn = new Button(m_header, SWT.PUSH);
		setStyle(m_userBtn,HEADER_USER_STYLE );
		setHexForeground(m_userBtn, m_colorFGUsername);		
		FormDataFactory.swtDefaults().top(50,-10).right(100, -10).applyTo(m_userBtn);
		// user name  
		Label userIcon = new Label(m_header, SWT.NONE);		
		FormDataFactory.swtDefaults().top(50,-16).right(m_userBtn, 0).width(32).height(32).applyTo(userIcon);	
		m_userIcon = userIcon;
			
		// error log button 
		m_errorLogButton = new Button(m_header, SWT.PUSH);
		setStyle(m_errorLogButton, HEADER_ERROR_STYLE);
		setHexForeground(m_errorLogButton, m_colorFGError);	
		FormDataFactory.swtDefaults().bottom(100, -8).right(100).applyTo(m_errorLogButton);
	}

	@Override
	public void compactHeader(final boolean compact) {
		if (m_header != null) {
			m_header.setVisible(!compact);
			final FormData layoutData = (FormData) m_header.getLayoutData();
			layoutData.height = compact ? 0: SWT.DEFAULT;
			m_header.setLayoutData(layoutData);		
			m_header.requestLayout();
		}
	}
	
	/* this method is not currently used, as all images are retrieved through CSS */
	protected Image portalImage(String name) {
		return  DisplayResourcesManager.getImage(IMAGE_PREFIX + name);
	}

}
