package com.brainwave.portal.theme.template.skin_css;

import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setHexBackground;
import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setHexForeground;
import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setStyle;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import com.brainwave.portal.ui.skin.PortalSkinBase;
import com.brainwave.portal.ui.utils.layout.FillLayoutFactory;
import com.brainwave.portal.ui.utils.layout.FormDataFactory;
import com.brainwave.portal.ui.utils.layout.FormLayoutFactory;
import com.brainwave.portal.ui.utils.widgets.BreadCrumbBar;

public class CustomMinimalPortalSkin extends PortalSkinBase {
	
	public CustomMinimalPortalSkin() {
		
	}

	@Override
	public void createContent(final Composite parent) {
		createHeader(parent);
		createToolbar(parent);
		createPageArea(parent);
	}
	
	@Override
	protected void createHeader(Composite parent) {
		// container
		final Composite header = new Composite(parent, SWT.NONE); 
		FormDataFactory.swtDefaults().left(0).right(100).height(30).applyTo(header);
		FormLayoutFactory.fillDefaults().margins(0, 0, 20, 0).applyTo(header);
	    setHexBackground(header, m_colorBGTop);	    
		m_header = header;
		
		// title
		Label _label = new Label(m_header, SWT.NONE);
		m_headerTitle = _label;
		setStyle(m_headerTitle,HEADER_TITLE_STYLE);
		setHexForeground(m_headerTitle, m_colorFGTitle);
		FormDataFactory.swtDefaults().top(0,5).left(0,  15).applyTo(m_headerTitle);

		m_userBtn = new Button(m_header, SWT.PUSH);
		setStyle(m_userBtn,HEADER_USER_STYLE );
		setHexForeground(m_userBtn, m_colorFGUsername);		
		FormDataFactory.swtDefaults().top(50,-10).right(100, -10).applyTo(m_userBtn);

	}
	
	private void createToolbar(Composite parent) {
		 m_toolbar = null; 		
	}

	private void createPageArea(final Composite parent) {
		m_breadCrumbBar = new BreadCrumbBar(parent, ">");
		FormDataFactory.swtDefaults().top(m_header, 0).left(0, 15).right(100, (-15)).height(10).applyTo(m_breadCrumbBar);
		m_pageArea = new Composite(parent, SWT.NONE);
		setStyle(m_pageArea, PAGE_AREA_STYLE);
		FormDataFactory.swtDefaults().top(m_breadCrumbBar, 0).bottom(100).left(0, 15).right(100, (-15)).applyTo(m_pageArea);
		FillLayoutFactory.fillDefaults().margins(0).applyTo(m_pageArea);
	}


	
	

}
