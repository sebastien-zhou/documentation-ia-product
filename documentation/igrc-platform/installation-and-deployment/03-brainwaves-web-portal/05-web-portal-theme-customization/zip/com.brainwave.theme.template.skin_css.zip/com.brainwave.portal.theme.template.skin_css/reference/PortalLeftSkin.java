package com.brainwave.portal.theme.skin;

import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setStyle;
import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setHexBackground;
import static com.brainwave.portal.ui.utils.widgets.WidgetExtensions.setHexForeground;
import static com.brainwave.portal.ui.utils.widgets.WidgetFactoryExtension.newButtonCssIcon;
import static com.brainwave.portal.ui.utils.widgets.WidgetFactoryExtension.newToggleCssIcon;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

import com.brainwave.iaudit.database.datasource.IDataSourceProvider;
import com.brainwave.portal.ui.skin.PortalSkinBase;
import com.brainwave.portal.ui.utils.layout.FillLayoutFactory;
import com.brainwave.portal.ui.utils.layout.FormDataFactory;
import com.brainwave.portal.ui.utils.layout.FormLayoutFactory;
import com.brainwave.portal.ui.utils.widgets.BreadCrumbBar;
import com.brainwave.portal.ui.visualization.navbar.VNavBarColors;
import com.brainwave.portal.ui.widgets.VNavTabs;
import com.google.inject.Inject;
import com.google.inject.name.Named;

public class PortalLeftSkin extends PortalSkinBase {
	
	protected static int MARGIN_TOP = 10;
	
	@Inject(optional = true)  @Named(IDataSourceProvider.COLOR2_FGTIMESLOT)  protected String m_colorFGTimeslot;
	@Inject(optional = true)  @Named(IDataSourceProvider.COLOR2_BGTIMESLOT)  protected String m_colorBGTimeslot;
	@Inject(optional = true)  @Named(IDataSourceProvider.COLOR2_FGSELITEM)  protected String m_colorFGSelectedItem;
	@Inject(optional = true)  @Named(IDataSourceProvider.COLOR2_BGSELITEM)  protected String m_colorBGSelectedItem;
	@Inject(optional = true)  @Named(IDataSourceProvider.COLOR2_BGITEM)  protected String m_colorBGItem;
	@Inject(optional = true)  @Named(IDataSourceProvider.COLOR2_FGSELCAT)  protected String m_colorFGSelectedCategory;
	@Inject(optional = true)  @Named(IDataSourceProvider.COLOR2_BGSELCAT)  protected String m_colorBGSelectedCategory;
	@Inject(optional = true)  @Named(IDataSourceProvider.COLOR2_FGTOOLBAR )  protected String m_colorFGToolbar;
	@Inject(optional = true)  @Named(IDataSourceProvider.COLOR2_BGTOOLBAR )  protected String m_colorBGToolbar;
	

	@Override
	public void createContent(final Composite parent) {
		createHeader(parent);
		final SashForm splitter = new SashForm(parent, SWT.HORIZONTAL);
		FormDataFactory.fillDefaults().top(m_header, 0).applyTo(splitter);
		createToolbar(splitter);
		createPageArea(splitter);
		splitter.setWeights(new int[] { 20, 80 });
	}

	protected void createHeader(final Composite parent) {
		super.createHeader(parent);
	}

	/**
	 * creates toolbar with navigation panel, timeslot button and header compact button 
	 */
	protected void createToolbar(final Composite parent) {

		// container 
		m_toolbar = new Composite(parent, SWT.NONE);
		setStyle(m_toolbar, TOOLBAR_STYLE);
		setHexBackground(m_toolbar, m_colorBGToolbar)  ; 
		FormLayoutFactory.swtDefaults().margins(10, 10, 0, 10).spacing(0).applyTo(m_toolbar);

		// header compact toggle

		m_headerCompactButton = newToggleCssIcon(m_toolbar, COMPACT_HEADER_STYLE);
		FormDataFactory.swtDefaults().top(0,-14).right(100,4).width(20).height(20).applyTo(m_headerCompactButton);

        //  main menu
		m_mainMenuButton = newButtonCssIcon(m_toolbar, MAIN_MENU_STYLE);
		FormDataFactory.swtDefaults().top(0).left(0).width(28).height(28).applyTo(m_mainMenuButton);
				
		final Button loadingIcon = newButtonCssIcon(m_toolbar, LOADING_STYLE);
		//loadingIcon.setText("toto");
		FormDataFactory.swtDefaults().top(0).left(m_mainMenuButton, 10).width(30).height(30).applyTo(loadingIcon);
		m_loadingIcon = loadingIcon;						
		// nav radioGroup 
		
		final VNavTabs navTabs = new VNavTabs(m_toolbar, SWT.NONE);
		final VNavBarColors colors = new VNavBarColors() ;
			colors.bg = m_colorBGToolbar  ; 
			colors.fg = m_colorFGToolbar ; 
			colors.bgSelectedCategory = m_colorBGSelectedCategory ; 
			colors.fgSelectedCategory = m_colorFGSelectedCategory  ; 
			colors.bgItem = m_colorBGItem  ; 
			colors.bgSelectedItem = m_colorBGSelectedItem  ; 
			colors.fgSelectedItem = m_colorFGSelectedItem  ; 
		navTabs.setColors(colors); 
		FormDataFactory.swtDefaults().left(0).right(100).bottom(100, (-20)).top(0, 40).applyTo(navTabs);	
		m_navBar = navTabs;
		
		m_timeslotLabel = new Button(m_toolbar, SWT.CENTER);
		setStyle(m_timeslotLabel, TIMESLOT_STYLE);
		setHexBackground(m_timeslotLabel, m_colorBGTimeslot);
		setHexForeground(m_timeslotLabel, m_colorFGTimeslot);			
		FormDataFactory.swtDefaults().top(0).right(100, -15).height(24).applyTo(m_timeslotLabel);
	}

	private void createPageArea(final Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		FormDataFactory.fillDefaults().applyTo(container);
		FormLayoutFactory.fillDefaults().applyTo(container);
		m_breadCrumbBar = new BreadCrumbBar(container, ">");
		FormDataFactory.swtDefaults().top(m_toolbar, 0).left(0, 15).right(100, (-15)).height(10).applyTo(m_breadCrumbBar);
		m_pageArea = new Composite(container, SWT.NONE);
		setStyle(m_pageArea, PAGE_AREA_STYLE);
		FormDataFactory.swtDefaults().top(m_breadCrumbBar, 0).bottom(100).left(0, 15).right(100, (-15)).applyTo(m_pageArea);
		FillLayoutFactory.fillDefaults().margins(0).applyTo(m_pageArea);
	}


}
