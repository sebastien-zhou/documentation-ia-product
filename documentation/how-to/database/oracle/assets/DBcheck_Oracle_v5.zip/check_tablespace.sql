Rem FILE     : check_tablespace
Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWAVE GRC
Rem DATE : 04/05/2021
Rem VERSION  : 2.0
Rem                                 
Rem
Rem GOAL    : Show information on the size and states of tablespaces.
Rem
Rem ###################################################


Rem Size of columns 
	
COL ts_             FOR A15            HEAD "TABLESPACE"  WRAPPED
COL st_             FOR A4             HEAD "STATE"  	  WRAPPED
COL fi_             FOR A46            HEAD "NAME OF FILE" WRAPPED
COL nu_             FOR 999            HEAD "NO"          WRAPPED
COL s2_             FOR 999999999      HEAD "SIZE (Ko)" WRAPPED

SET LINES 120
SET PAGES 1000
set HEAD off

COLUMN DUMMY NOPRINT
COMPUTE SUM OF s2_ ON DUMMY
BREAK ON DUMMY SKIP 1


TTITLE CENTER ============================= SKIP 1 -
	CENTER  ' NAMES AND SIZE OF DATAFILES '         SKIP 1 -
	CENTER ============================= SKIP 2

select t.tablespace_name DUMMY, t.tablespace_name ts_,
        decode (t.status,'ONLINE','ON','OFFLINE','OFF','?')         st_,
	f.file_id	 nu_,
	f.file_name      fi_,
	f.bytes / 1024   s2_
from dba_tablespaces t, dba_data_files f
where t.tablespace_name = f.tablespace_name
order by 1,2,5;


-- TTITLE ON

select 'NUMBER OF FILES : ' || count(*) from v$datafile;
select 'MAX NUMBER OF FILES : ' || substr(value,1,10) from v$parameter 
where name ='db_files';

SET HEAD ON
