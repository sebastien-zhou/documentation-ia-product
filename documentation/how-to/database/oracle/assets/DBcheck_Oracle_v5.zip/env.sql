Rem FILE     : env
Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWAVE GRC
Rem VERSION  : 1.0
Rem DATE : 04/05/2021
Rem
REM ------------------------------------------------------------------------ 
REM PURPOSE: 
REM    To set the environement variables 
REM         Username = XXX
REM ------------------------------------------------------------------------

set head off

set echo off
set feed off
set ver off

define USERNAME='IGRC'
