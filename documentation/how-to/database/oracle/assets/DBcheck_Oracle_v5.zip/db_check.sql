Rem FILE    : Check_database
Rem AUTHOR  : ROUX David
Rem COMPANY : BRAINWAVE GRC
Rem version : 4.0
Rem Date : 04/05/2021
Rem SYNTAX  : sqlplus system/<password>@<connect_string> @omv_db_check.sql d:\tmp\omv_db_report.lst (Windows)
Rem SYNTAX  : sqlplus system/<password>@<connect_string> @omv_db_check.sql /tmp/omv_db_report.lst (Unix)
Rem
Rem DATA 
Rem            In               : FULL PATH NAME FOR THE LOG FILE
Rem
Rem            Out              : "check_database.lst" file
Rem                                   
Rem
Rem GOAL : To generate a report on IGRC database
Rem You are attempting to grant SELECT_CATALOG_ROLE to the user IGRC to enable the user  
Rem to SELECT all exported catalog views and tables in the data dictionary
Rem
Rem ######################################################

set head off
set echo off

Rem  Path of result file
     
    SPOOL &1

Rem  Sql Scripts

    @@env.sql    
	@@sga_parameters.sql
	@@user_roles.sql
	@@object.sql
	@@occup_tablespace.sql
	@@check_tablespace.sql
	@@fragment_tablespace.sql
	@@fragment_object.sql
	@@show_rollback.sql
	@@show_redolog.sql
	@@count_records.sql
	@@recordspertimeslot.sql
	@@check_max_crecorduid.sql
	@@count_records_portaltables.sql
	@@count_records_importtables.sql

Rem  End 

	SPOOL OFF
        PROMPT
	PROMPT  Result file in &1
    PROMPT

exit


