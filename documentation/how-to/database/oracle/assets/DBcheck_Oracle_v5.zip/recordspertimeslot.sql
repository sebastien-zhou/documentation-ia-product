Rem FILE     : recordspertimeslot
Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWAVE GRC
Rem VERSION  : 1.0
Rem DATE : 04/05/2021
Rem
REM ------------------------------------------------------------------------ 
REM PURPOSE: 
REM    Count the number of records in the given tables per timeslot 
REM ------------------------------------------------------------------------

set head on
set term on
SET ECHO OFF
SET FEED OFF
set pages 1000
set lines 180
SET CONCAT '.'

COL   CPROPERTIES HEAD  'PROPERTIES' 		FOR   A15 WRAPPED
COL   CVALUE 	HEAD  'VALUE' 		FOR   A15 WRAPPED


--
	TTITLE CENTER ========================= SKIP 1 -
	CENTER  ' Records per importdate ' SKIP 1 -
	CENTER ========================= SKIP 3


select count(*) as "Identity",cimportdate as "Import date" from &USERNAME..tidentity join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Accounts",cimportdate as "Import date" from &USERNAME..taccount join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Organisation",cimportdate as "Import date" from &USERNAME..torganisation join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Application",cimportdate as "Import date" from &USERNAME..tapplication join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Groups",cimportdate as "Import date" from &USERNAME..tgroup join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Permission",cimportdate as "Import date" from &USERNAME..tpermission join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Right",cimportdate as "Import date" from &USERNAME..tright join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Right Group",cimportdate as "Import date" from &USERNAME..trightgroup join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Repository",cimportdate as "Import date" from &USERNAME..trepository join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Asset",cimportdate as "Import date" from &USERNAME..tasset join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "View Aggregated Right",cimportdate as "Import date" from &USERNAME..vaggregatedright join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Control Log",cimportdate as "Import date" from &USERNAME..tcontrollog join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Control Results" from &USERNAME..tcontrolresult;

-- Theoretical rights
select count(*) as "Theoretical Permission",cimportdate as "Import date" from &USERNAME..ttheoricalpermission join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Theoretical Right",cimportdate as "Import date" from &USERNAME..ttheoricalright join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;

-- SAP tables
select count(*) as "Activity Pair",cimportdate as "Import date" from &USERNAME..tactivitypair join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "Activity role",cimportdate as "Import date" from &USERNAME..tactivityrole join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;
select count(*) as "SOD matrix",cimportdate as "Import date" from &USERNAME..tsodmatrix join &USERNAME..timportlog on ctimeslotfk=cimportloguid group by cimportdate order by 2;

-- Metadata tables
select count(*) as "Metadata",cimportdate as "Import date" from &USERNAME..tmetadata m inner join &USERNAME..timportlog l on m.ctimeslotfk = l.cimportloguid group by cimportdate order by 2 ;
select count(*) as "Metadata Values",cimportdate as "Import date" from &USERNAME..tmetadata m inner join &USERNAME..timportlog l on m.ctimeslotfk = l.cimportloguid group by cimportdate order by 2;


-- List the contents of tproperties table
select cpropertiesuid CPROPERTIES, cvalue CVALUE from &USERNAME..tproperties;

-- List the contents of timportlog table
select * from &USERNAME..timportlog order by cproductversion;

