Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWAVE GRC
Rem VERSION  : 2.0
Rem Date : 04/05/2021
Rem 
Rem GOAL                     : show all IGRC Roles
Rem 
Rem #######################################################


Rem Size of columns 

	COL   tx_r 	HEAD  'OCCUPATION RATE|(%)'     FOR   999 WRAPPED
	COL   vol_r 	HEAD  'VOLUME|FREE|(Ko)'	FOR   999999999 WRAPPED
	COL   vol_o 	HEAD  'VOLUME|OCCUPIED|(Ko)' 	FOR   999999999 WRAPPED
	COL   vol 	HEAD  'VOLUME|TOTAL|(Ko)' 	FOR   999999999 WRAPPED
	COL   Owner HEAD  'OWNER' 		FOR   A15 WRAPPED
	COL   Role 	HEAD  'ROLE' 		FOR   A15 WRAPPED
	COL   Administration HEAD 'ADMINISTRATION' FOR   A15 WRAPPED
	COL   Default_role HEAD 'DEFAULT ROLE' FOR   A15 WRAPPED

set lines 120
SET HEAD ON
SET FEED OFF



TTITLE CENTER =================================== SKIP 1 -
CENTER  ' USERS ROLES  ' SKIP 1 -
CENTER =================================== SKIP 2

select grantee Owner, granted_role Role, admin_option Administration, default_role Default_role from sys.dba_role_privs where grantee like '%&USERNAME%' order by grantee;

PROMPT  
SET FEED OFF