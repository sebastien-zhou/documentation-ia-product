Rem FILE     : occup_tablespace
Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWAVE GRC
Rem VERSION  : 1.0
Rem DATE : 04/05/2021
Rem                                   
Rem GOAL : Tablespaces occupation rate.
Rem
Rem ################################################

Rem Size of columns 

	COL   tx_r 	HEAD  'OCCUPATION RATE|(%)'     FOR   999 WRAPPED
	COL   vol_r 	HEAD  'VOLUME|FREE|(Ko)'	FOR   999999999 WRAPPED
	COL   vol_o 	HEAD  'VOLUME|OCCUPIED|(Ko)' 	FOR   999999999 WRAPPED
	COL   vol 	HEAD  'VOLUME|TOTAL|(Ko)' 	FOR   999999999 WRAPPED
	COL   ts 	HEAD  'TABLESPACE' 		FOR   A27 WRAPPED

SET LINES 120
SET PAGES 1000
set heading on

REM Path of the Result file 

REM Debut 
	TTITLE CENTER ================================================================ SKIP 1 -
	CENTER  ' OCCUPATION RATE AND NUMBER OF DATAFILES  ' SKIP 1 -
	CENTER ================================================================ SKIP 2
PROMPT
PROMPT
SELECT  t.tablespace_name       ts,
        (nvl(u.bytes,0)+nvl(f.bytes,0))/ 1024 vol,
        nvl (u.bytes,0)/1024	vol_o,
        nvl (f.bytes,0)/1024    vol_r,
        ceil((nvl(u.bytes,0) / (nvl(u.bytes,0) + nvl(f.bytes,0))) * 100)  tx_r
FROM    SYS.SM$TS_FREE f,
        SYS.SM$TS_USED u,
        dba_tablespaces t
WHERE   t.tablespace_name = f.tablespace_name (+)
AND     t.tablespace_name = u.tablespace_name (+)
AND	t.contents != 'TEMPORARY'
GROUP BY        t.tablespace_name,
                u.bytes,
                f.bytes
ORDER BY 5 desc;

REM Debut 
	TTITLE CENTER ========================================================= SKIP 1 -
	CENTER  ' TEMP USAGE  ' SKIP 1 -
	CENTER ================================================================ SKIP 2
PROMPT
PROMPT
COL TABLESPACE_SIZE FOR 999,999,999,999
COL ALLOCATED_SPACE FOR 999,999,999,999
COL FREE_SPACE FOR 999,999,999,999
 
SELECT *
FROM   dba_temp_free_space;

PROMPT
PROMPT


COL NAME FOR A32
SELECT
NAME, STATUS, ENABLED,
BYTES, BLOCKS, BLOCK_SIZE
FROM V$TEMPFILE;


SET HEAD OFF

TTITLE OFF
 
SELECT 'Total Oracle database size : '|| ROUND(SUM((nvl(u.bytes,0)+nvl(f.bytes,0))/1024/1024),2) || 'Mo    Total Occupied : ' || ROUND(SUM(nvl(u.bytes,0)/1024/1024),2) || 'Mo' FROM
SYS.SM$TS_FREE f,
SYS.SM$TS_USED u,
dba_tablespaces t
WHERE   t.tablespace_name = f.tablespace_name (+)
AND     t.tablespace_name = u.tablespace_name (+);

PROMPT
SELECT 'Total Occupied by IGRC (index + data): '|| ROUND(SUM((nvl(u.bytes,0))/1024/1024),2) || 'Mo'
FROM
SYS.SM$TS_USED u
WHERE u.tablespace_name like '&USERNAME%';




