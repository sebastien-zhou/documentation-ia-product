Rem FILE     : fragment_tablespace
Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWAVE GRC
Rem VERSION  : 1.0
Rem DATE : 04/05/2021
Rem
REM ------------------------------------------------------------------------ 
REM PURPOSE: 
REM    Displays tablespace free space and fragmentation for each 
REM    tablespace,  Prints the total size, the amount of space available, 
REM    and a summary of freespace fragmentation in that tablespace. 
REM ------------------------------------------------------------------------ 
REM EXAMPLE: 
REM     
REM SPACE AVAILABLE IN TABLESPACES 
REM     
REM    TABLESPACE_NAME                TOT_SIZE     TOT_FREE     PCT_FREE 
REM    -------------------------- ------------ ------------ ------------ 
REM        MAX_FREE  CHUNKS_FREE 
REM    ------------ ------------ 
REM    RBS                              60,817,408   57,085,952           94 
REM      52,426,752           16 
REM    SYSTEM                           94,371,840    5,386,240            6 
REM       5,013,504            3 
REM    TEMP                                563,200      561,152          100 
REM         133,120            5 
REM    USERS                             1,048,576       26,624            3 
REM          26,624            1 
REM
REM  

SET HEAD OFF
SET HEADING ON
SET FEED OFF
	
TTITLE CENTER ============================= SKIP 1 -
CENTER  ' TABLESPACES FRAGMENTATION ' SKIP 1 -
CENTER ============================= SKIP 1 -
' ' SKIP 1 -
'Displays tablespace free space and fragmentation for each ' SKIP 1 -
'tablespace,  Prints the total size, the amount of space available, ' SKIP 1 -
'and a summary of freespace fragmentation in that tablespace. ' SKIP 2
set lines 100

Rem Size of columns 

	COL   Pct_Free 	HEAD  'FREE RATE|(%)'           FOR   999 WRAPPED
	COL   Chunks_Free HEAD  'FREE EXTENTS'           FOR   999 WRAPPED
	COL   Tot_Free 	HEAD  'VOLUME|FREE|(Mo)'	FOR   999999999 WRAPPED
	COL   largest 	HEAD  'MAX FREE|(Mo)' 		FOR   999999999 WRAPPED
	COL   Tot_Size 	HEAD  'VOLUME|TOTAL|(Mo)' 	FOR   999999999 WRAPPED
	COL   tname 	HEAD  'TABLESPACE' 		FOR   A27 WRAPPED

  
select a.tablespace_name tname,ROUND (sum(a.tots)/1024,2) Tot_Size,   
ROUND(sum(a.sumb)/1024,2) Tot_Free,  
ROUND(sum(a.sumb)*100/sum(a.tots),2) Pct_Free,   
ROUND(sum(a.largest)/1024,2) Max_Free,sum(a.chunks) Chunks_Free
from   
(  
select tablespace_name,0 tots,ROUND (sum(bytes)/1024,2) sumb,   
ROUND (max(bytes)/1024,2) largest,count(*) chunks  
from dba_free_space a  
group by tablespace_name  
union  
select tablespace_name,ROUND (sum(bytes)/1024,2) tots,0,0,0 from
dba_data_files  
group by tablespace_name) a  
group by a.tablespace_name;

PROMPT

