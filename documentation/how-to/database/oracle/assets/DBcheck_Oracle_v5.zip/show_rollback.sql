Rem FILE     : show_rollback
Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWAVE GRC
Rem VERSION  : 1.0     
Rem Date : 04/05/2021   
Rem 
Rem GOAL : Show definitions of rollback segments
Rem 
Rem ################################################

set pages 100
set lines 100
set head on
set term on
set echo off
--
col TABLESPACE_NAME format a15
col OWNER format a6
col SEGMENT_NAME format a12
col STATUS format a7
col FILE_ID format 9999
col MIN_EXT format 99999
col MAX_EXT format 99999999
col PCT_INCR format 99999
--
break on TABLESPACE_NAME on OWNER nodup
--
PROMPT
	TTITLE CENTER ============================== SKIP 1 -
	CENTER  ' ROLLBACK SEGMENT DEFINITION ' SKIP 1 -
	CENTER ============================== SKIP 2
select 
	TABLESPACE_NAME,
	OWNER,
	FILE_ID,
	SEGMENT_NAME,
	INITIAL_EXTENT INITIAL_,
	NEXT_EXTENT NEXT_,
	MIN_EXTENTS MIN_EXT,
	MAX_EXTENTS MAX_EXT,
	PCT_INCREASE PCT_INCR,
	STATUS
from   
	dba_rollback_segs
order by
	TABLESPACE_NAME,
	SEGMENT_NAME;

