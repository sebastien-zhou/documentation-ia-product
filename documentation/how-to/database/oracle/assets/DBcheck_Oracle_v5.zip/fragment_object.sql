Rem FILE     : fragment_tablespace
Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWVAE GRC
Rem VERSION  : 1.0
Rem Date : 04/05/2021
Rem ----------------------------------------

COL segment_name HEAD "SEGMENT NAME" FOR A30 TRUNCATE
COL segment_type HEAD "SEGMENT TYPE" FOR A10  WRAPPED
COL tablespace_name HEAD "TABLESPACE NAME" FOR A15 TRUNCATE
COL extents HEAD "NB_SEGMENT" FOR 9999 WRAPPED

TTITLE CENTER ================================ SKIP 1 -
CENTER  ' OBJECTS FRAGMENTATION ' SKIP 1 -
CENTER ================================ SKIP 1 -
' ' SKIP 1 -
'DATA and INDEX TABLESPACE  ' SKIP 1 -
' ' SKIP 1 -  
'For these tablespaces, the concern for fragmentation is not at the  ' SKIP 1 -
'tablespace level, but rather, the object level. If you drop and recreate many  ' SKIP 1 -
'tables or indexes, this will cause fragmentation at the tablespace level.  ' SKIP 1 -
'Objects that stay in this tablespace generally do not cause tablespace  ' SKIP 1 -
'fragmentation. But tables and indexes can get fragmented. One of the most  ' SKIP 1 -
'common ways to fragment a table or index is if you are doing large deletes and  ' SKIP 1 -
'then inserts frequently. When you delete a lot of rows and then immediately  ' SKIP 1 -
'insert rows, this will cause the table to grow. The reason you see this effect  ' SKIP 1 -
'is because of delayed block cleanout. This will cause fragmentation in the  ' SKIP 1 -
'table.  ' SKIP 1 -
'	When you do any dml on a table, Oracle issues a fast commit, which  ' SKIP 1 -
'means that those blocks have been marked for change, but the change will not  ' SKIP 1 -
'actually be implemented until the block is touched again(i.e. doing a select  ' SKIP 1 -
'statement after the delete will force Oracle to go and touch the block and  ' SKIP 1 -
'actually delete the rows and then free up the space). This is delayed block  ' SKIP 1 -
'cleanout.  ' SKIP 1 -
'	Indexes will also become fragmented with inserts and deletes because  ' SKIP 1 -
'of the way indexes are implemented. When a row is deleted, Oracle will not  ' SKIP 1 -
'reuse the index space. Pctused for indexes is always 0, which means the index  ' SKIP 1 -
'blocks will not be put on the free list for reuse. Therefore, indexes are  ' SKIP 1 -
'always growing and can become very fragmented. This is the tradeoff for more  ' SKIP 1 -
'efficient index performance.  ' SKIP 3

select tablespace_name, segment_name, segment_type, extents from dba_segments
where extents>=1 and owner='&USERNAME'
/ 