Rem AUTHOR   : ROUX David
Rem COMPANY	 : BRAINWAVE GRC
Rem VERSION  : 2.0
Rem DATE : 04/05/2021
Rem 
Rem 
Rem GOAL     : show all IGRC objects
Rem 
Rem #######################################################

set lines 180
SET HEAD ON
SET FEED OFF

COL otype HEAD "OBJECT_TYPE" FOR A32  WRAPPED
COL oname HEAD "OBJECT_NAME" FOR A32 WRAPPED
COL nb HEAD "NB RECORDS" FOR 999999999 WRAPPED

COL	tbn	HEAD "TABLE" FOR A32 WRAPPED
COL idn HEAD "INDEX" FOR A32 WRAPPED
COL cln HEAD "COLUMN" FOR A32 WRAPPED
COL ps HEAD "POSITION" FOR 9 WRAPPED
COL status HEAD "STATUS" FOR A7 WRAPPED
COL typ HEAD "TYPE" FOR A10 WRAPPED
COL lanalys HEAD "LAST ANALYZED" FOR A15 WRAPPED


REM Debut
	TTITLE CENTER =================================== SKIP 1 -
	CENTER  ' LIST OF IGRC ORACLE OBJECTS ' SKIP 1 -
	CENTER =================================== SKIP 2

	SELECT  object_type otype, COUNT(*) nb FROM dba_objects WHERE owner like '&USERNAME%' GROUP BY owner, object_type ORDER BY owner, object_type;

	PROMPT
	TTITLE 'In Release iGRC 2017 R3 / ADER ' SKIP 1 -
	SKIP 1 -
	'  ------------- ' SKIP 1 - 
	'  INDEX = 450 / 500 ' SKIP 1 -
	'  TABLE = 140 / 145 ' SKIP 1 -
	'  SEQUENCE = 67 / 67' SKIP 1 -
	'  TRIGGER = 67 / 60 ' SKIP 1 -
	'  PACKAGE = 0 / 0	 ' SKIP 1 -
	'  VIEWS = 30 / 32	 ' SKIP 1 -	
	SKIP 1 -
	SKIP 1

	PROMPT

    SELECT DISTINCT OBJECT_TYPE otype, OBJECT_NAME oname
    FROM   dba_objects
	WHERE	OWNER = '&USERNAME'
	ORDER BY OBJECT_TYPE;


	TTITLE CENTER ===================== SKIP 1 -
	CENTER ' LIST OF INDEXES ' SKIP 1 -
	CENTER ===================== SKIP 2
	PROMPT
	BREAK ON REPORT
	COMPUTE NUM LABEL 'AU TOTAL' OF all_indexes.index_name ON REPORT


	select
		all_ind_columns.table_name tbn, 
		all_indexes.index_name idn,
		all_ind_columns.column_name cln, 
		all_ind_columns.column_position ps, 
		all_indexes.status status,
		all_indexes.uniqueness typ,
		all_indexes.last_analyzed lanalys
	from all_indexes, all_ind_columns 
		where 
			all_indexes.index_name = all_ind_columns.index_name
			and all_indexes.owner = all_ind_columns.index_owner
			and all_indexes.owner = 'IGRC'
	order by 
		all_ind_columns.index_owner,
		all_ind_columns.table_name,
		all_indexes.index_name,
		all_ind_columns.column_position;
	
    PROMPT  
SET HEAD OFF