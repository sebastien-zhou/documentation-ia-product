rem --------------------------------------------------------------------------
rem Filename:   check_max_crecorduid.sql
rem Purpose:    Check the max number of crecorduid column for iGRC tables concerned
rem             using PL/SQL
rem Author:	David Roux
rem COMPANY : BRAINWAVE GRC
rem Date : juin 2021
rem Version : 1.1
rem ---------------------------------------------------------------------------
whenever sqlerror continue
SET ECHO OFF
SET FEED OFF
set pages 100
set lines 125
set heading on
set term on

PROMPT 
PROMPT  ===================================================================================
PROMPT  =              Verify max number of crecorduid column for ALL tables             =
PROMPT  ===================================================================================
PROMPT 

set serveroutput ON size 1000000

DECLARE
  t_c1_tname      all_tables.table_name%TYPE;
  t_command       varchar2(200);
  t_cid           integer;
  t_total_records number(10);
  stat            integer;
  row_count       integer;
  t_limit         integer := 0;    -- Only show tables with more rows
  cursor c1 is select table_name from all_tab_columns where column_name ='CRECORDUID' and owner = '&USERNAME' and table_name not like 'TPORTAL%' AND table_name not like 'VPORTAL%' order by table_name;
  
BEGIN 
  t_limit := 0;
  open c1;
  loop
        fetch c1 into t_c1_tname;
        exit when c1%NOTFOUND;
		
			
		t_command := 'SELECT MAX(crecorduid) FROM &USERNAME' ||'.'||t_c1_tname;

        /* Open a cursor */
        t_cid := DBMS_SQL.OPEN_CURSOR;

        /* SQL Statement to be parsed the last parameter defines how the statement is treated. */
		/* DB to which the program is connected */
        DBMS_SQL.PARSE(t_cid,t_command,dbms_sql.native);

		/* Defining an output variable */
        DBMS_SQL.DEFINE_COLUMN(t_cid,1,t_total_records);
  
        /* Execute will carry out the statement and return the number of rows processed  */
		/* Fetch The data will be converted into the datatype specified by the define_colum */
        /* EXECUTE_AND_FETCH combines the execute and fetch operations in one call */

        /* stat := DBMS_SQL.EXECUTE(t_cid); */
        /* row_count := DBMS_SQL.FETCH_ROWS(t_cid); */
		row_count := DBMS_SQL.EXECUTE_AND_FETCH(t_cid,FALSE);

        /* Column_value is used to actually return the data */
        DBMS_SQL.COLUMN_VALUE(t_cid,1,t_total_records);

        if t_total_records >= t_limit then
                DBMS_OUTPUT.PUT_LINE(rpad(t_c1_tname,55,' ')||
                        to_char(t_total_records,'9999999999')||' (max crecorduid)');
        end if;
  
        /* Close the cursor */
        DBMS_SQL.CLOSE_CURSOR(t_cid);
  end loop;
        DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
  close c1; 
END;
/

PROMPT
PROMPT End
