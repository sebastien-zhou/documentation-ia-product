Rem FILE     : show_redolog
Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWAVE GRC
Rem VERSION  : 2.0
Rem DATE : 04/05/2021
Rem 
Rem GOAL      : show the definition of redo logs
Rem 
Rem ######################################################

set pages 100
set lines 180
set head on
set term on
set echo off
--
	TTITLE CENTER ========================= SKIP 1 -
	CENTER  ' REDO LOGS DEFINITION ' SKIP 1 -
	CENTER ========================= SKIP 3
col member format a40
select 
	a.member, 
	b.* 
from   
	v$logfile a, v$log b
where
	a.group#=b.group#;

PROMPT  
PROMPT  End
