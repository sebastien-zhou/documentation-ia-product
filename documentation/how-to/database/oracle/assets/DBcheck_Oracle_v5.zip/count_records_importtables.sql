rem --------------------------------------------------------------------------
rem Filename:   count_records_importtables.sql
rem Purpose:    Check the number of records for import tables per timeslot
rem             using PL/SQL
rem Author:	David Roux
rem COMPANY : BRAINWAVE GRC
rem Date : august 2020
rem Version : 1.0
rem ---------------------------------------------------------------------------
whenever sqlerror continue
SET ECHO OFF
SET FEED OFF
set pages 1000
set lines 180
set heading on
set term on

PROMPT 
PROMPT  ===================================================================================
PROMPT  =              Check the number of records per timeslot for import tables         =
PROMPT  ===================================================================================
PROMPT 

set serveroutput ON size 1000000

DECLARE
  t_c1_tname      all_tables.table_name%TYPE;
  rec_tab 		  dbms_sql.desc_tab;
  rec_rec 		  dbms_sql.desc_rec; 
  t_command       varchar2(200);
  t_ts 			  varchar2(200);  
  t_cid           integer;
  t_total_records number(10);
  v_t_total_records number(10);
  v_t_ts 			  varchar2(200);  
  return_code 	  integer;
  col_cnt 		  integer;
  rc 			  number;  
 
  cursor c1 is select table_name from all_tab_columns where column_name ='CIMPORTLOGFK' and owner = '&USERNAME' and table_name like 'TIMPORT%' order by table_name;
   
  
BEGIN 

  open c1;
  loop
        fetch c1 into t_c1_tname;
        exit when c1%NOTFOUND;
		
			
		t_command := 'SELECT NVL(COUNT(1),0), cimportlogfk FROM &USERNAME' ||'.'||t_c1_tname || ' group by cimportlogfk order by cimportlogfk';
		
		  
		/*DBMS_OUTPUT.PUT_LINE(t_command);
*/
        /* Open a cursor */
        t_cid := DBMS_SQL.OPEN_CURSOR;

        /* SQL Statement to be parsed the last parameter defines how the statement is treated. */
		/* DB to which the program is connected */
        DBMS_SQL.PARSE(t_cid,t_command,dbms_sql.native);

        /* Execute */ 
        return_code := DBMS_SQL.EXECUTE(t_cid);   

		/* to fill in the table rec_tab with the description of each column. Here 2 columns count(1) and ctimeslotfk */ 
		DBMS_SQL.DESCRIBE_COLUMNS(t_cid, col_cnt, rec_tab);


        /* just to map the position of the column from the statement to the defined variable. */
        DBMS_SQL.DEFINE_COLUMN(t_cid, 1, t_total_records); 
		DBMS_SQL.DEFINE_COLUMN(t_cid, 2, t_ts,200); 

        loop 
             rc := dbms_sql.fetch_rows(t_cid); 
               if rc > 0 then 
			        /* Column_value is used to actually return the data */
                    dbms_sql.column_value(t_cid, 1, v_t_total_records); 
                    dbms_sql.column_value(t_cid, 2, v_t_ts); 
					DBMS_OUTPUT.PUT_LINE(rpad(t_c1_tname,55,' ')|| to_char(v_t_total_records,'999999999')||'    ' || v_t_ts); 
                    else 
                         exit; 
                    end if; -- if rc > 0 then. 
        end loop loop1; 
  
        /* Close the cursor */
        DBMS_SQL.CLOSE_CURSOR(t_cid);
  end loop;
        DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
  close c1; 
END;
/

PROMPT
PROMPT End

