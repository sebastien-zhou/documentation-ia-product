Rem FILE    : sga_parameters
Rem AUTHOR   : ROUX David
Rem COMPANY  : BRAINWAVE GRC
Rem VERSION  : 1.0
Rem Date 04/05/2021
Rem
Rem
Rem GOAL     : To show the parameters, sga stats and the size of the IGRC Database.
Rem
Rem
Rem ###############################################


	SET HEAD OFF
    SET FEED OFF
	SET PAGES 1000

	COL tsga HEAD "TAILLE SGA" FOR A50 TRUNCATE
	COL tname HEAD "PARAMETRE" FOR A35  WRAPPED
	COL tdefaut HEAD "DEFAUT" FOR A6 TRUNCATE
	COL tvalue HEAD "VALEUR" FOR A32 WRAPPED

    PROMPT
	PROMPT
	TTITLE CENTER ========================================= SKIP 1 -
	CENTER  ' INSTANCE NAME - ORACLE DABASE SIZE - SGA ' SKIP 1 -
	CENTER ========================================= SKIP 2
	SELECT 'Instance ' || name || ' creee le ' || 
                to_date (created,'YYYY/MM/DD:HH24:MI:SS') || ' en ' || LOG_MODE
        FROM v$database; 
        TTITLE OFF
        SELECT banner
        FROM v$version;

	PROMPT
	        
        SELECT 'Total memory size for SGA : ' || ROUND (sum(value)/1024,2) || ' Ko :' from v$sga;
        SELECT '    ' || name, ROUND (value/1024,2), 'Ko'  from v$sga;
	
	PROMPT
        PROMPT
	TTITLE CENTER ============================================== SKIP 1 -
	CENTER ' LIST OF PARAMETERS - SHOW PARAMETERS (INIT.ORA)' SKIP 1 -
	CENTER SKIP 1 -
	CENTER ============================================== SKIP 2

	PROMPT
	
        SELECT 	name	tname,
		decode (isdefault,'TRUE','Oui','FALSE','Non') tdefaut,
		value tvalue
        FROM v$parameter
        ORDER by name; 

	PROMPT


